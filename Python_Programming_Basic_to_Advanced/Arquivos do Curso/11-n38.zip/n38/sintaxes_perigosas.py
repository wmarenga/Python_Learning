"""
== -> é usado para checar valor

is -> é usado para checar se os objetos são os mesmos
"""

