public class TiposJava{

    public static void main(String[] args){
        String nome = "Geek University";

        nome = 42;

        System.out.println(nome);
    }
}
