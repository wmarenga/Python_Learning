# idade = 42
#
# print(type(idade))
#
# idade = 'Quarenta e dois'
#
# print(type(idade))
#


# if True:
#     resultado = 1 + 'Geek'
# else:
#     resultado = 1 + 41
#
# print(resultado)

