from models.calcular import Calcular

calc: Calcular = Calcular(1)

print(calc)

