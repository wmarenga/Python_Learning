from models.produto import Produto

ps4 = Produto('Playstation 4', 1789.44)
xbox = Produto('Xbox 360', 1699.00)

print(ps4)
print(xbox)
